const express = require('express');
const { graphqlHTTP } = require('express-graphql');
const { buildSchema } = require('graphql');

// Defina seu esquema GraphQL
const schema = buildSchema(`
  type Query {
    hello: String
  }
`);

// Defina os resolvers
const root = {
  hello: () => 'Olá, mundo!',
};

const app = express();

// Crie um endpoint GraphQL usando o middleware express-graphql
app.use(
  '/graphql',
  graphqlHTTP({
    schema: schema,
    rootValue: root,
    graphiql: true, // Isso permite usar a interface GraphiQL para testar consultas GraphQL no navegador.
  })
);

const PORT = process.env.PORT || 4000;

app.listen(PORT, () => {
  console.log(`Servidor GraphQL em execução em http://localhost:${PORT}/graphql`);
});

